#ifndef CLSCLIENTES_H_INCLUDED
#define CLSCLIENTES_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class Clientes{
    private:
        int _dniCliente;
        char _nombre[30];
        char _apellido[30];
        bool _estado;
    public:
        Clientes();
        ~Clientes();
        const char *getNombre();
        const char *getApellido();
        int getDniCliente();
        bool getEstado();
//        void setNombre ();
//        void setApellido ();
        void setDniCliente (int dniCliente);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar();
};

#endif // CLSCLIENTES_H_INCLUDED
