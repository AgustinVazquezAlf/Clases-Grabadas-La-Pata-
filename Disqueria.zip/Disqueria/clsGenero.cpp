#include <iostream>
using namespace std;
#include "clsGenero.h"
#include "Funciones.h"

const char *Genero::getNombre(){
    return _nombre;
}
const char *Genero::getDescripcion(){
    return _descripcion;
}
int  Genero::getIDGenero(){
    return _IDGenero;
}
bool Genero::getEstado(){
    return _estado;
}
//void Genero::setNombre (){
//    cargarCadena(_nombre,30);
//}
//void Genero::setDescripcion (){
//    cargarCadena(_descripcion,30);
//}

void Genero::setIDGenero (int IDGenero){
    _IDGenero=IDGenero;
}

void Genero::setEstado (bool estado){
    _estado=estado;
}

void Genero::Mostrar(){

}

void Genero::Cargar(){

}
