#include <iostream>
#include "Funciones.h"
#include "clsClientes.h"
#include "clsArchivoClientes.h"
#include "clsInterprete.h"
#include "clsArchivoInterpretes.h"
#include "clsGenero.h"
#include "clsArchivoGenero.h"
#include "clsDiscos.h"
#include "clsArchivoDiscos.h"
#include "clsEmpleados.h"
#include "clsArchivoEmpleados.h"
#include "clsVentas.h"
#include "clsArchivoVentas.h"
#include "clsDetalleVenta.h"
#include "clsArchivoDetalleVenta.h"
using namespace std;



void cargarCadena(char *pal, int tam){
    int i;
    fflush (stdin); ///limpia el buffer de entrada para que la carga se haga sin caracteres que hayan quedado sin usar
    for(i=0; i<tam;i++){
        pal[i]=cin.get();
        if(pal[i]=='\n')break;
    }
    pal[i]='\0';
    fflush(stdin); ///vuelve a limpiar el buffer para eliminar los caracteres sobrantes
}

void altaInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL DNI: ";
    cin>>id;
    if(arc.buscarRegistro(id)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar();
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaGenero(){
    Genero obj;
    ArchivoGenero arc;
    int id;
    cout<<"INGRESE EL ID: ";
    cin>>id;
    if(arc.buscarRegistro(id)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar();
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO: ";
    cin>>codigo;
    if(arc.buscarRegistro(codigo)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar();
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL CODIGO: ";
    cin>>dni;
    if(arc.buscarRegistro(dni)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar();
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaCliente(){
    Clientes obj;
    ArchivoClientes arc;
    int dni;
    cout<<"INGRESE EL CODIGO: ";
    cin>>dni;
    if(arc.buscarRegistro(dni)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar();
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void altaVenta(){
    Clientes obj;
    ArchivoClientes arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA: ";
    cin>>numeroFactura;
    if(arc.buscarRegistro(numeroFactura)>=0){
        cout<<"EL CODIGO INGRESADO YA EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj.Cargar();
    if(arc.grabarRegistro(obj)){
        cout<<"SE AGREGO EL REGISTRO CORRECTAMENTE"<<endl;
    }else{
        cout<<"NO SE PUDO AGREGAR EL REGISTRO"<<endl;
    }
}

void bajaInterprete(){
    Interprete obj;
    ArchivoInterpretes arc;
    int id;
    cout<<"INGRESE EL ID DEL INTERPRETE A DAR DE BAJA: ";
    cin>>id;
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL INTERPRETE INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaGenero(){
    Genero obj;
    ArchivoGenero arc;
    int id;
    cout<<"INGRESE EL ID DEL GENERO A DAR DE BAJA: ";
    cin>>id;
    int pos = arc.buscarRegistro(id);
    if(pos<0){
        cout<<"EL ID INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL GENERO INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaDisco(){
    Discos obj;
    ArchivoDiscos arc;
    int codigo;
    cout<<"INGRESE EL CODIGO DEL DISCO A DAR DE BAJA: ";
    cin>>codigo;
    int pos = arc.buscarRegistro(codigo);
    if(pos<0){
        cout<<"EL CODIGO INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL DISCO INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaEmpleado(){
    Empleados obj;
    ArchivoEmpleados arc;
    int dni;
    cout<<"INGRESE EL DNI DEL EMPLEADO A DAR DE BAJA: ";
    cin>>dni;
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL EMPLEADO INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaCliente(){
    Clientes obj;
    ArchivoClientes arc;
    int dni;
    cout<<"INGRESE EL DNI DEL CLIENTE A DAR DE BAJA: ";
    cin>>dni;
    int pos = arc.buscarRegistro(dni);
    if(pos<0){
        cout<<"EL DNI INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"EL CLIENTE INGRESADO YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}

void bajaVenta(){
    Ventas obj;
    ArchivoVentas arc;
    int numeroFactura;
    cout<<"INGRESE EL NUMERO DE FACTURA DE LA VENTA A DAR DE BAJA: ";
    cin>>numeroFactura;
    int pos = arc.buscarRegistro(numeroFactura);
    if(pos<0){
        cout<<"EL NUMERO DE FACTURA INGRESADO NO EXISTE EN EL ARCHIVO"<<endl;
        return;
    }
    obj = arc.leerRegistro(pos);
    if(obj.getEstado()==false){
        cout<<"LA VENTA INGRESADA YA SE ENCUENTRA DADO DE BAJA"<<endl;
        return;
    }
    obj.setEstado(false);
    arc.modificarRegistro(obj, pos);
}



void listarInterpretes(){
    ArchivoInterpretes arc;
    arc.listarRegistros();
}

void listarGeneros(){
    ArchivoGenero arc;
    arc.listarRegistros();
}

void listarDiscos(){
    ArchivoDiscos arc;
    arc.listarRegistros();
}

void listarEmpleados(){
    ArchivoEmpleados arc;
    arc.listarRegistros();
}

void listarClientes(){
    ArchivoClientes arc;
    arc.listarRegistros();
}

void listarVentas(){
    ArchivoVentas arc;
    arc.listarRegistros();
}

void menuPrincipal(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - MENU INTERPRETES"<<endl;
        cout<<"2 - MENU GENEROS"<<endl;
        cout<<"3 - MENU DISCOS"<<endl;
        cout<<"4 - MENU EMPLEADOS"<<endl;
        cout<<"5 - MENU CLIENTES"<<endl;
        cout<<"6 - MENU VENTAS"<<endl;
        cout<<"0 - SALIR DEL PROGRAMA"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                menuInterpretes();
                break;
            case 2:
                menuGeneros();
                break;
            case 3:
                menuDiscos();
                break;
            case 4:
                menuEmpleados();
                break;
            case 5:
                menuClientes();
                break;
            case 6:
                menuVentas();
                break;
            case 0:
                return;
        }
    }
}

void menuInterpretes(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU INTERPRETES"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - ALTA INTERPRETE"<<endl;
        cout<<"2 - BAJA INTERPRETE"<<endl;
        cout<<"3 - MODIFICAR INTERPRETE"<<endl;
        cout<<"4 - LISTAR INTERPRETES"<<endl;
        cout<<"5 - ORDENAR INTERPRETES"<<endl;
        cout<<"6 - FILTRAR INTERPRETES"<<endl;
        cout<<"0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaInterprete();
                break;
            case 2:
                bajaInterprete();
                break;
            case 3:
                //modificarInterprete();
                break;
            case 4:
                listarInterpretes();
                break;
            case 5:
                menuOrdenarInterpretes();
                break;
            case 6:
                //menuFiltrarInterpretes();
               break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarInterpretes(){
    int opc;
    while(true){
        system("cls");
        cout<<"MENU ORDENAR INTERPRETES"<<endl;
        cout<<"===================="<<endl;
        cout<<"ORDENAR POR:"<<endl;
        cout<<"1 - FECHA DE NACIMIENTO"<<endl;
        cout<<"2 - ORDEN ALFABETICO"<<endl;
        cout<<"3 - CANTIDAD DE DISCOS"<<endl;
        cout<<"0 - VOLVER AL MENU INTERPRETES"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                //ordenarInterpretePorFecha();
                break;
            case 2:
                //ordenarInterpretePorAlfabetico();
                break;
            case 3:
                //ordenarInterpretePorCantidadDiscos();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}


void menuGeneros(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU GENEROS"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - ALTA GENERO"<<endl;
        cout<<"2 - BAJA GENERO"<<endl;
        cout<<"3 - MODIFICAR GENERO"<<endl;
        cout<<"4 - LISTAR GENEROS"<<endl;
        cout<<"5 - ORDENAR GENEROS"<<endl;
        cout<<"6 - FILTRAR GENEROS"<<endl;
        cout<<"0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaGenero();
                break;
            case 2:
                bajaGenero();
                break;
            case 3:
                //modificarGenero();
                break;
            case 4:
                listarGeneros();
                break;
            case 5:
                menuOrdenarGeneros();
                break;
            case 6:
               // menuFiltrarGeneros();
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarGeneros(){
    int opc;
    while(true){
        system("cls");
        cout<<"MENU ORDENAR GENEROS"<<endl;
        cout<<"===================="<<endl;
        cout<<"ORDENAR POR:"<<endl;
        cout<<"1 - ORDEN ALFABETICO"<<endl;
        cout<<"2 - CANTIDAD DE DISCOS"<<endl;
        cout<<"0 - VOLVER AL MENU GENEROS"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                //ordenarGeneroPorAlfabetico();
                break;
            case 2:
                //ordenarGeneroPorCantidadDiscos();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuDiscos(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU DISCOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - ALTA DISCO"<<endl;
        cout<<"2 - BAJA DISCO"<<endl;
        cout<<"3 - MODIFICAR DISCO"<<endl;
        cout<<"4 - LISTAR DISCOS"<<endl;
        cout<<"5 - ORDENAR DISCOS"<<endl;
        cout<<"6 - FILTRAR DISCOS"<<endl;
        cout<<"0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaDisco();
                break;
            case 2:
                bajaDisco();
                break;
            case 3:
                //modificarDisco();
                break;
            case 4:
                listarDiscos();
                break;
            case 5:
                menuOrdenarDiscos();
                break;
            case 6:
                //menuFiltrarDiscos();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarDiscos(){
    int opc;
    while(true){
        system("cls");
        cout<<"MENU ORDENAR DISCOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"ORDENAR POR:"<<endl;
        cout<<"1 - FECHA DE LANZAMIENTO"<<endl;
        cout<<"2 - ORDEN ALFABETICO"<<endl;
        cout<<"3 - PRECIO"<<endl;
        cout<<"0 - VOLVER AL MENU DISCOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                //ordenarDiscoPorFecha();
                break;
            case 2:
                //ordenarDiscoPorAlfabetico();
                break;
            case 3:
                //ordenarDiscoPorPrecio();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuEmpleados(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU EMPLEADOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - ALTA EMPLEADO"<<endl;
        cout<<"2 - BAJA EMPLEADO"<<endl;
        cout<<"3 - MODIFICAR EMPLEADO"<<endl;
        cout<<"4 - LISTAR EMPLEADOS"<<endl;
        cout<<"5 - ORDENAR EMPLEADOS"<<endl;
        cout<<"6 - FILTRAR EMPLEADOS"<<endl;
        cout<<"0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaEmpleado();
                break;
            case 2:
                bajaEmpleado();
                break;
            case 3:
                //modificarEmpleado();
                break;
            case 4:
                listarEmpleados();
                break;
            case 5:
                menuOrdenarEmpleados();
                break;
            case 6:
                //menuFiltrarEmpleados();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarEmpleados(){
    int opc;
    while(true){
        system("cls");
        cout<<"MENU ORDENAR EMPLEADOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"ORDENAR POR:"<<endl;
        cout<<"1 - NUMERO DE DNI"<<endl;
        cout<<"2 - ORDEN ALFABETICO"<<endl;
        cout<<"3 - SUELDO"<<endl;
        cout<<"0 - VOLVER AL MENU EMPLEADOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                //ordenarEmpleadoPorDNI();
                break;
            case 2:
                //ordenarEmpleadoPorAlfabetico();
                break;
            case 3:
                //ordenarEmpleadoPorSueldo();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuClientes(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU CLIENTES"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - ALTA CLIENTE"<<endl;
        cout<<"2 - BAJA CLIENTE"<<endl;
        cout<<"3 - MODIFICAR CLIENTE"<<endl;
        cout<<"4 - LISTAR CLIENTES"<<endl;
        cout<<"5 - ORDENAR CLIENTES"<<endl;
        cout<<"6 - FILTRAR CLIENTES"<<endl;
        cout<<"0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaCliente();
                break;
            case 2:
                bajaCliente();
                break;
            case 3:
                //modificarCliente();
                break;
            case 4:
                listarClientes();
                break;
            case 5:
                menuOrdenarClientes();
                break;
            case 6:
                //menuFiltrarClientes();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarClientes(){
    int opc;
    while(true){
        system("cls");
        cout<<"MENU ORDENAR CLIENTES"<<endl;
        cout<<"===================="<<endl;
        cout<<"ORDENAR POR:"<<endl;
        cout<<"1 - NUMERO DE DNI"<<endl;
        cout<<"2 - ORDEN ALFABETICO"<<endl;
        cout<<"0 - VOLVER AL MENU CLIENTES"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                //ordenarClientePorDNI();
                break;
            case 2:
                //ordenarClientePorAlfabetico();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuVentas(){
    int opc;
    while(true){
        system("cls");
        cout<<"    MENU VENTAS"<<endl;
        cout<<"===================="<<endl;
        cout<<"1 - ALTA VENTA"<<endl;
        cout<<"2 - BAJA VENTA"<<endl;
        cout<<"3 - MODIFICAR VENTA"<<endl;
        cout<<"4 - LISTAR VENTAS"<<endl;
        cout<<"5 - ORDENAR VENTAS"<<endl;
        cout<<"6 - FILTRAR VENTAS"<<endl;
        cout<<"0 - VOLVER AL MENU PRINCIPAL"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                altaVenta();
                break;
            case 2:
                bajaVenta();
                break;
            case 3:
                //modificarVenta();
                break;
            case 4:
                listarVentas();
                break;
            case 5:
                menuOrdenarVentas();
                break;
            case 6:
                //menuFiltrarVentas();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}

void menuOrdenarVentas(){
    int opc;
    while(true){
        system("cls");
        cout<<"MENU ORDENAR DISCOS"<<endl;
        cout<<"===================="<<endl;
        cout<<"ORDENAR POR:"<<endl;
        cout<<"1 - FECHA DE EMISION"<<endl;
        cout<<"2 - IMPORTE TOTAL"<<endl;
        cout<<"3 - NUMERO DE FACTURA"<<endl;
        cout<<"0 - VOLVER AL MENU VENTAS"<<endl;
        cout<<"===================="<<endl;
        cout<<"INGRESE LA OPCION: ";
        cin>>opc;
        system("cls");
        switch(opc){
            case 1:
                //ordenarVentaPorFecha();
                break;
            case 2:
                //ordenarVentaPorImporte();
                break;
            case 3:
                //ordenarVentaPorNumeroDeFactura();
                break;
            case 0:
                return;
        }
        system("pause");
    }
}
