#include <iostream>
#include "clsFecha.h"
using namespace std;

Fecha::Fecha(int d, int m, int a){
    dia=d;
    mes=m;
    anio=a;
}



void Fecha::Cargar(){
    cout<<"DIA: ";
    cin>>dia;
    cout<<"MES: ";
    cin>>mes;
    cout<<"ANIO: ";
    cin>>anio;
}

void Fecha::Mostrar(){
    cout<<"FECHA: "<<dia<<"/"<<mes<<"/"<<anio<<endl;
}
