#ifndef CLSARCHIVOCLIENTES_H_INCLUDED
#define CLSARCHIVOCLIENTES_H_INCLUDED
#include <iostream>
using namespace std;
#include "clsClientes.h"

class ArchivoClientes{
    private:
        char nombre[30];
    public:
        ArchivoClientes (const char *n="clientes.dat");
        Clientes leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (Clientes);
        bool modificarRegistro (Clientes, int);
        void listarRegistros();

};


#endif // CLSARCHIVOCLIENTES_H_INCLUDED
