#ifndef CLSARCHIVODISCOS_H_INCLUDED
#define CLSARCHIVODISCOS_H_INCLUDED
#include <iostream>
using namespace std;

class ArchivoDiscos{
    private:
        char nombre[30];
    public:
        ArchivoDiscos (const char *n="discos.dat");
        Discos leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (Discos);
        bool modificarRegistro (Discos, int);
        void listarRegistros();

};


#endif // CLSARCHIVODISCOS_H_INCLUDED
