#ifndef CLSINTERPRETE_H_INCLUDED
#define CLSINTERPRETE_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class Interprete{
    private:
        int _IDInterprete;
        char _nombre[30];
        char _apellido[30];
        Fecha _fechaNacimiento;
        bool _estado;
    public:
        int getIDInterprete();
        const char *getNombre();
        const char *getApellido();
        Fecha getFechaNacimiento();
        bool getEstado();
//        void setNombre (const char *nombre);
//        void setApellido (const char *apellido);
        void setIdInterprete (int);
        void setFechaNacimiento (Fecha fechaNacimiento);
        void setEstado (bool e);
        void Mostrar();
        void Cargar();
};


#endif // CLSINTERPRETE_H_INCLUDED
