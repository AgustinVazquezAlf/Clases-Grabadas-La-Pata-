#include <iostream>
using namespace std;
#include "clsDetalleVenta.h"

int DetalleVenta::getCodigoDeBarras(){
    return _codigoDeBarras;
}

int DetalleVenta::getNumeroFactura(){
    return _numeroFactura;
}

int DetalleVenta::getDniCliente(){
    return _dniCliente;
}

float DetalleVenta::getPrecio(){
    return _precio;
}

int DetalleVenta::getCantidad(){
    return _cantidad;
}

bool DetalleVenta::getEstado(){
    return _estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DetalleVenta::setCodigoDeBarras (int codigoDeBarras){
    _codigoDeBarras=codigoDeBarras;
}

void DetalleVenta::setNumeroFactura (int numeroFactura){
    _numeroFactura=numeroFactura;
}

void DetalleVenta::setDniCliente(int dniCliente){
    _dniCliente=dniCliente;
}

void DetalleVenta::setCantidad (int cantidad){
    _cantidad=cantidad;
}

void DetalleVenta::setPrecio (int precio){
    _precio=precio;
}

void DetalleVenta::setEstado (bool estado){
    _estado=estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void DetalleVenta::Mostrar(){

}

void DetalleVenta::Cargar(){

}
