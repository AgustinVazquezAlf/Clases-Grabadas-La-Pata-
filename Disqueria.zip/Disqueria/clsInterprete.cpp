#include <iostream>
using namespace std;
#include "clsInterprete.h"
#include "Funciones.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Interprete::getIDInterprete(){
    return _IDInterprete;
}

const char *Interprete::getNombre(){
    return _nombre;
}

const char *Interprete::getApellido(){
    return _apellido;
}

Fecha Interprete::getFechaNacimiento(){
    return _fechaNacimiento;
}

bool Interprete::getEstado(){
    return _estado;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//void Interprete::setNombre (const char *nombre)(){
//
//}
//void Interprete::setApellido (const char *apellido)(){
//
//}
void Interprete::setIdInterprete (int IDInterprete){
    _IDInterprete=IDInterprete;
}

void Interprete::setFechaNacimiento (Fecha fechaNacimiento){
    _fechaNacimiento=fechaNacimiento;
}

void Interprete::setEstado (bool estado){
    _estado=estado;
}

void Interprete::Mostrar(){

}

void Interprete::Cargar(){
}
