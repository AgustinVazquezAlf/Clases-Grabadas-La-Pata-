#include <iostream>
using namespace std;
#include "clsEmpleados.h"
#include "Funciones.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const char *Empleados::getNombre(){
    return _nombre;
}
const char *Empleados::getApellido(){
    return _apellido;
}

int  Empleados::getDniEmpleado(){
    return _dniEmpleado;
}

float Empleados::getSueldo(){
    return _sueldo;
}
bool Empleados::getEstado(){
    return _estado;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//void Empleados::setNombre (){
//  cargarCadena(_nombre,30);
//}
//void Empleados::setApellido(){
// cargarCadena(_apellido,30);
//}

void Empleados::setDniEmpleado (int dniEmpleado){
    _dniEmpleado=dniEmpleado;
}

void Empleados::setSueldo (float sueldo){
    _sueldo=sueldo;
}

void Empleados::setEstado (bool estado){
    _estado=estado;
}

void Empleados::Mostrar(){

}

void Empleados::Cargar(){

}
