#include <iostream>
using namespace std;
#include "clsVentas.h"
#include "Funciones.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Ventas::getNumeroFactura(){
    return _numeroFactura;
}

float Ventas::getImporte(){
    return _importe;
}

Fecha Ventas::getFechaEmision(){
    return _fechaEmision;
}

int Ventas::getDniEmpleado(){
    return _dniEmpleado;
}

int Ventas::getDniCliente(){
    return _dniCliente;
}

bool Ventas::getEstado(){
    return _estado;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Ventas::setNumeroFactura (int numeroFactura){
    _numeroFactura=numeroFactura;
}

void Ventas::setImporte (float importe){
    _importe=importe;
}

void Ventas::setFechaEmision (Fecha fechaEmision){
    _fechaEmision=fechaEmision;
}

void Ventas::setDniEmpleado (int dniEmpleado){
    _dniEmpleado=dniEmpleado;
}

void Ventas::setDniCliente (int dniCliente){
    _dniCliente=dniCliente;
}

void Ventas::setEstado (bool estado){
    _estado=estado;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Ventas::Mostrar(){

}

void Ventas::Cargar(){

}
