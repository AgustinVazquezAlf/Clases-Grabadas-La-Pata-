#ifndef CLSARCHIVOGENERO_H_INCLUDED
#define CLSARCHIVOGENERO_H_INCLUDED
#include <iostream>
using namespace std;

class ArchivoGenero{
    private:
        char nombre[30];
    public:
        ArchivoGenero (const char *n="genero.dat");
        Genero leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (Genero);
        bool modificarRegistro (Genero, int);
        void listarRegistros();

};


#endif // CLSARCHIVOGENERO_H_INCLUDED
