#ifndef CLSFECHA_H_INCLUDED
#define CLSFECHA_H_INCLUDED

class Fecha{
    private:
        int dia, mes, anio;
    public:
        Fecha(int d=0, int m=0, int a=0);
        void Mostrar();
        void Cargar();
};

#endif // CLSFECHA_H_INCLUDED
