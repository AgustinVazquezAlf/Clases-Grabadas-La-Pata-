#include "clsFecha.h"
#include <iostream>
using namespace std;
#include "clsDiscos.h"
#include "Funciones.h"


bool  Discos::getEstado(){
    return _estado;
}

int   Discos::getCodigoDeBarras(){
    return _codigoDeBarras;
}

int   Discos::getIDInterprete(){
    return _IDInterprete;
}

const char  *Discos::getNombreDisco(){
    return _nombreDelDisco;
}

int   Discos::getIDGenero(){
    return _IDGenero;
}

Fecha   Discos::getFechaDeLanzamiento(){
    return _fechaDeLanzamiento;
}

const char  *Discos::getOrigen(){
    return _origen;
}

float Discos::getPrecio(){
    return _precio;
}

int   Discos::getFormato(){
    return _formato;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void  Discos::setCodigoDeBarras (int codigoDeBarras){
    _codigoDeBarras=codigoDeBarras;
}

void  Discos::setIDInterprete (int IDInterprete){
    _IDInterprete=IDInterprete;
}

void  Discos::setIDGenero (int IDGenero){
    _IDGenero=IDGenero;
}

//void  Discos::setNombreDisco (){
//    cargarCadena(_nombreDelDisco,30);
//}

void  Discos::setFechaDeLanzamiento (Fecha fechaDeLanzamiento){
    _fechaDeLanzamiento=fechaDeLanzamiento;
}

//void  Discos::setOrigen (){
//    cargarCadena(_origen,30);
//}

void  Discos::setPrecio (float precio){
    _precio=precio;
}

void  Discos::setFormato (int formato){
    _formato=formato;
}

void  Discos::setEstado (bool estado){
    _estado=estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void  Discos::Mostrar(){

}

void  Discos::Cargar(){

}

