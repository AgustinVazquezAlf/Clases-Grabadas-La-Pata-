#ifndef CLSARCHIVOEMPLEADOS_H_INCLUDED
#define CLSARCHIVOEMPLEADOS_H_INCLUDED
#include <iostream>
using namespace std;

class ArchivoEmpleados{
    private:
        char nombre[30];
    public:
        ArchivoEmpleados (const char *n="empleados.dat");
        Empleados leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (Empleados);
        bool modificarRegistro (Empleados, int);
        void listarRegistros();

};


#endif // CLSARCHIVOEMPLEADOS_H_INCLUDED
