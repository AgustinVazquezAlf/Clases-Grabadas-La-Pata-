#include <iostream>
using namespace std;
#include "clsClientes.h"
#include "Funciones.h"


Clientes::Clientes(){

}
Clientes::~Clientes(){

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const char *Clientes::getNombre(){
    return _nombre;
}
const char *Clientes::getApellido(){
    return _apellido;
}
int  Clientes::getDniCliente(){
    return _dniCliente;
}
bool Clientes::getEstado(){
    return _estado;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//void Clientes::setNombre(){
//     cargarCadena(_nombre,30);
//}
//void Clientes::setApellido(){
// cargarCadena(_apellido,30);
//}
void Clientes::setDniCliente(int dniCliente){
    _dniCliente=dniCliente;

}
void Clientes::setEstado(bool estado){
    _estado=estado;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Clientes::Mostrar(){
    cout<<"CLIENTE: "<<endl;
    cout<<"NOMBRE: "<<getNombre()<<endl;
    cout<<"APELLIDO: "<<getApellido()<<endl;
    cout<<"DNI: "<<getDniCliente()<<endl;
}
void Clientes::Cargar(){
    cout<<"CLIENTE"<<endl;
    cout<<"NOMBRE: ";
    cargarCadena(_nombre,30);
    cout<<"APELLIDO: ";
    cargarCadena(_apellido,30);
    cout<<"DNI: ";
    int auxDNI;
    cin>>auxDNI;
    setDniCliente(auxDNI);
}
