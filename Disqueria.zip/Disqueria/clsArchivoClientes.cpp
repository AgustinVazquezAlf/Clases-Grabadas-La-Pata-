#include <iostream>
#include <cstring>
#include "clsClientes.h"
#include "clsArchivoClientes.h"
using namespace std;

ArchivoClientes::ArchivoClientes(const char *n){
    strcpy(nombre, n);
}

Clientes ArchivoClientes::leerRegistro(int pos){
    FILE *p;
    Clientes obj;
    p=fopen(nombre ,"rb");
    if(p==nullptr){
        obj.setDniCliente(-2);
        return obj;
    }
    obj.setDniCliente(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoClientes::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (Clientes);
}

int ArchivoClientes::buscarRegistro(int dni){
    int cantReg = contarRegistros();
    Clientes obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getDniCliente()==dni){
            return i;
        }
    }
    return -1;
}

bool ArchivoClientes::grabarRegistro(Clientes obj){
    FILE *p;
    p=fopen(nombre, "ab");
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoClientes::modificarRegistro(Clientes obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+");
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoClientes::listarRegistros(){
    int cantReg = contarRegistros();
    Clientes obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}
