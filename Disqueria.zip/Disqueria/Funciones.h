#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
using namespace std;

void cargarCadena(char *pal, int tam);
void altaInterprete();
void bajaInterprete();
void modificarInterprete();
void listarInterpretes();
void ordenarInterpretePorFecha();
void ordenarInterpretePorAlfabetico();
void ordenarInterpretePorCantidadDiscos();
void ordenarGeneroPorAlfabetico();
void ordenarGeneroPorCantidadDiscos();
///MENU
void menuPrincipal();
///SUB MENUES
void menuInterpretes();
void menuGeneros();
void menuDiscos();
void menuEmpleados();
void menuClientes();
void menuVentas();
///SUB-SUB MENUES
void menuOrdenarInterpretes();
void menuFiltrarInterpretes();
void menuOrdenarGeneros();
void menuFiltrarGeneros();
void menuOrdenarDiscos();
void menuFiltrarDiscos();
void menuOrdenarEmpleados();
void menuFiltrarEmpleados();
void menuOrdenarClientes();
void menuFiltrarClientes();
void menuOrdenarVentas();
void menuFiltrarVentas();
#endif // FUNCIONES_H_INCLUDED
