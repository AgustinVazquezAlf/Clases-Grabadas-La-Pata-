#ifndef CLSARCHIVODETALLEVENTA_H_INCLUDED
#define CLSARCHIVODETALLEVENTA_H_INCLUDED
#include <iostream>
using namespace std;

class ArchivoDetalleVenta{
    private:
        char nombre[30];
    public:
        ArchivoDetalleVenta (const char *n="detalleventa.dat");
        DetalleVenta leerRegistro (int);
        int contarRegistros();
        int buscarRegistro (int);
        bool grabarRegistro (DetalleVenta);
        bool modificarRegistro (DetalleVenta, int);
        void listarRegistros();

};


#endif // CLSARCHIVODETALLEVENTA_H_INCLUDED
