#ifndef CLSEMPLEADOS_H_INCLUDED
#define CLSEMPLEADOS_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class Empleados{
    private:
        int _dniEmpleado;
        char _nombre[30];
        char _apellido[30];
        float _sueldo;
        bool _estado;
    public:
        const char *getNombre();
        const char *getApellido();
        int getDniEmpleado();
        float getSueldo();
        bool getEstado();
//        void setNombre ();
//        void setApellido ();
        void setDniEmpleado (int dniEmpleado);
        void setSueldo (float sueldo);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar();

};


#endif // CLSEMPLEADOS_H_INCLUDED
