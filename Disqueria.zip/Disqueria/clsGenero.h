#ifndef CLSGENERO_H_INCLUDED
#define CLSGENERO_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class Genero{
    private:
        int _IDGenero;
        char _nombre[30];
        char _descripcion[30];
        bool _estado;
    public:
        const char *getNombre();
        const char *getDescripcion();
        int getIDGenero();
        bool getEstado();
//        void setNombre (const char *nombre);
//        void setDescripcion (const char *descripcion);
        void setIDGenero (int IDGenero);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar();

};


#endif // CLSGENERO_H_INCLUDED
