#include <iostream>
#include <cstring>
#include "clsInterprete.h"
#include "clsArchivoInterpretes.h"
using namespace std;

ArchivoInterpretes::ArchivoInterpretes(const char *n){
    strcpy(nombre, n);
}

Interprete ArchivoInterpretes::leerRegistro(int pos){
    FILE *p;
    Interprete obj;
    p=fopen(nombre ,"rb");
    if(p==nullptr){
        obj.setIdInterprete(-2);
        return obj;
    }
    obj.setIdInterprete(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoInterpretes::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (Interprete);
}

int ArchivoInterpretes::buscarRegistro(int id){
    int cantReg = contarRegistros();
    Interprete obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getIDInterprete()==id){
            return i;
        }
    }
    return -1;
}

bool ArchivoInterpretes::grabarRegistro(Interprete obj){
    FILE *p;
    p=fopen(nombre, "ab");
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoInterpretes::modificarRegistro(Interprete obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+");
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoInterpretes::listarRegistros(){
    int cantReg = contarRegistros();
    Interprete obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}

