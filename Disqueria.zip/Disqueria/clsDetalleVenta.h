#ifndef CLSDETALLEVENTA_H_INCLUDED
#define CLSDETALLEVENTA_H_INCLUDED
#include <iostream>
#include "clsFecha.h"
using namespace std;

class DetalleVenta{
    private:
        int _codigoDeBarras;
        int _numeroFactura;
        int _dniCliente;
        float _precio;
        int _cantidad;
        bool _estado;
    public:
        int getCodigoDeBarras();
        int getNumeroFactura();
        int getDniCliente();
        int getCantidad();
        float getPrecio();
        bool getEstado();
        void setCodigoDeBarras (int codigoDeBarras);
        void setNumeroFactura (int numeroFactura);
        void setDniCliente(int DniCliente);
        void setCantidad (int cantidad);
        void setPrecio (int precio);
        void setEstado (bool estado);
        void Mostrar();
        void Cargar();
};


#endif // CLSDETALLEVENTA_H_INCLUDED
