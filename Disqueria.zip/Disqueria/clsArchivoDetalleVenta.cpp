#include <iostream>
#include <cstring>
#include "clsDetalleVenta.h"
#include "clsArchivoDetalleVenta.h"
using namespace std;

ArchivoDetalleVenta::ArchivoDetalleVenta(const char *n){
    strcpy(nombre, n);
}

DetalleVenta ArchivoDetalleVenta::leerRegistro(int pos){
    FILE *p;
    DetalleVenta obj;
    p=fopen(nombre ,"rb");
    if(p==nullptr){
        obj.setCodigoDeBarras(-2);
        return obj;
    }
    obj.setCodigoDeBarras(-1);
    fseek(p, sizeof obj * pos, 0);
    fread(&obj, sizeof obj, 1, p);
    fclose(p);
    return obj;
}

int ArchivoDetalleVenta::contarRegistros(){
    FILE *p;
    p=fopen(nombre, "rb");
    if(p==NULL){
        return -1;
    }
    fseek(p, 0, 2);
    int tam=ftell(p);
    fclose(p);
    return tam/sizeof (DetalleVenta);
}

int ArchivoDetalleVenta::buscarRegistro(int cod){
    int cantReg = contarRegistros();
    DetalleVenta obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
       if(obj.getCodigoDeBarras()==cod){
            return i;
        }
    }
    return -1;
}

bool ArchivoDetalleVenta::grabarRegistro(DetalleVenta obj){
    FILE *p;
    p=fopen(nombre, "ab");
    if(p==NULL){
        return false;
    }
    bool escribio = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return escribio;
}

bool ArchivoDetalleVenta::modificarRegistro(DetalleVenta obj, int pos){
    FILE *p;
    p=fopen(nombre, "rb+");
    if(p==NULL){
        return false;
    }
    fseek(p, pos * sizeof obj, 0);
    bool modifico = fwrite(&obj, sizeof obj, 1, p);
    fclose(p);
    return modifico;
}

void ArchivoDetalleVenta::listarRegistros(){
    int cantReg = contarRegistros();
    DetalleVenta obj;
    for(int i=0; i<cantReg; i++){
        obj = leerRegistro(i);
        if(obj.getEstado()){
            obj.Mostrar();
            cout<<endl;
        }
    }
}
